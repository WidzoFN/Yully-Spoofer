﻿namespace yully_spoofer_v5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.metroUserControl1 = new MetroFramework.Controls.MetroUserControl();
            this.siticoneCustomGradientPanel1 = new Siticone.UI.WinForms.SiticoneCustomGradientPanel();
            this.siticoneRoundedGradientButton5 = new Siticone.UI.WinForms.SiticoneRoundedGradientButton();
            this.siticoneRoundedGradientButton4 = new Siticone.UI.WinForms.SiticoneRoundedGradientButton();
            this.siticoneRoundedGradientButton3 = new Siticone.UI.WinForms.SiticoneRoundedGradientButton();
            this.siticoneRoundedGradientButton2 = new Siticone.UI.WinForms.SiticoneRoundedGradientButton();
            this.siticoneRoundedGradientButton1 = new Siticone.UI.WinForms.SiticoneRoundedGradientButton();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.siticoneCustomGradientPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // metroUserControl1
            // 
            this.metroUserControl1.Location = new System.Drawing.Point(621, 156);
            this.metroUserControl1.Name = "metroUserControl1";
            this.metroUserControl1.Size = new System.Drawing.Size(8, 8);
            this.metroUserControl1.TabIndex = 0;
            // 
            // siticoneCustomGradientPanel1
            // 
            this.siticoneCustomGradientPanel1.Controls.Add(this.siticoneRoundedGradientButton5);
            this.siticoneCustomGradientPanel1.Controls.Add(this.siticoneRoundedGradientButton4);
            this.siticoneCustomGradientPanel1.Controls.Add(this.siticoneRoundedGradientButton3);
            this.siticoneCustomGradientPanel1.Controls.Add(this.siticoneRoundedGradientButton2);
            this.siticoneCustomGradientPanel1.Controls.Add(this.siticoneRoundedGradientButton1);
            this.siticoneCustomGradientPanel1.Controls.Add(this.label1);
            this.siticoneCustomGradientPanel1.Controls.Add(this.panel1);
            this.siticoneCustomGradientPanel1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.siticoneCustomGradientPanel1.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.siticoneCustomGradientPanel1.FillColor3 = System.Drawing.Color.DimGray;
            this.siticoneCustomGradientPanel1.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.siticoneCustomGradientPanel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneCustomGradientPanel1.Location = new System.Drawing.Point(0, -1);
            this.siticoneCustomGradientPanel1.Name = "siticoneCustomGradientPanel1";
            this.siticoneCustomGradientPanel1.ShadowDecoration.Parent = this.siticoneCustomGradientPanel1;
            this.siticoneCustomGradientPanel1.Size = new System.Drawing.Size(182, 97);
            this.siticoneCustomGradientPanel1.TabIndex = 1;
            // 
            // siticoneRoundedGradientButton5
            // 
            this.siticoneRoundedGradientButton5.BackColor = System.Drawing.Color.Transparent;
            this.siticoneRoundedGradientButton5.CheckedState.Parent = this.siticoneRoundedGradientButton5;
            this.siticoneRoundedGradientButton5.CustomImages.Parent = this.siticoneRoundedGradientButton5;
            this.siticoneRoundedGradientButton5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.siticoneRoundedGradientButton5.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.siticoneRoundedGradientButton5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneRoundedGradientButton5.ForeColor = System.Drawing.Color.DimGray;
            this.siticoneRoundedGradientButton5.HoveredState.Parent = this.siticoneRoundedGradientButton5;
            this.siticoneRoundedGradientButton5.Location = new System.Drawing.Point(162, 2);
            this.siticoneRoundedGradientButton5.Name = "siticoneRoundedGradientButton5";
            this.siticoneRoundedGradientButton5.ShadowDecoration.Parent = this.siticoneRoundedGradientButton5;
            this.siticoneRoundedGradientButton5.Size = new System.Drawing.Size(17, 16);
            this.siticoneRoundedGradientButton5.TabIndex = 6;
            this.siticoneRoundedGradientButton5.Click += new System.EventHandler(this.siticoneRoundedGradientButton5_Click);
            // 
            // siticoneRoundedGradientButton4
            // 
            this.siticoneRoundedGradientButton4.BackColor = System.Drawing.Color.Transparent;
            this.siticoneRoundedGradientButton4.CheckedState.Parent = this.siticoneRoundedGradientButton4;
            this.siticoneRoundedGradientButton4.CustomImages.Parent = this.siticoneRoundedGradientButton4;
            this.siticoneRoundedGradientButton4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneRoundedGradientButton4.ForeColor = System.Drawing.Color.White;
            this.siticoneRoundedGradientButton4.HoveredState.Parent = this.siticoneRoundedGradientButton4;
            this.siticoneRoundedGradientButton4.Location = new System.Drawing.Point(94, 34);
            this.siticoneRoundedGradientButton4.Name = "siticoneRoundedGradientButton4";
            this.siticoneRoundedGradientButton4.ShadowDecoration.Parent = this.siticoneRoundedGradientButton4;
            this.siticoneRoundedGradientButton4.Size = new System.Drawing.Size(77, 25);
            this.siticoneRoundedGradientButton4.TabIndex = 4;
            this.siticoneRoundedGradientButton4.Text = "Clean";
            this.siticoneRoundedGradientButton4.Click += new System.EventHandler(this.siticoneRoundedGradientButton4_Click);
            // 
            // siticoneRoundedGradientButton3
            // 
            this.siticoneRoundedGradientButton3.BackColor = System.Drawing.Color.Transparent;
            this.siticoneRoundedGradientButton3.CheckedState.Parent = this.siticoneRoundedGradientButton3;
            this.siticoneRoundedGradientButton3.CustomImages.Parent = this.siticoneRoundedGradientButton3;
            this.siticoneRoundedGradientButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneRoundedGradientButton3.ForeColor = System.Drawing.Color.White;
            this.siticoneRoundedGradientButton3.HoveredState.Parent = this.siticoneRoundedGradientButton3;
            this.siticoneRoundedGradientButton3.Location = new System.Drawing.Point(10, 34);
            this.siticoneRoundedGradientButton3.Name = "siticoneRoundedGradientButton3";
            this.siticoneRoundedGradientButton3.ShadowDecoration.Parent = this.siticoneRoundedGradientButton3;
            this.siticoneRoundedGradientButton3.Size = new System.Drawing.Size(77, 25);
            this.siticoneRoundedGradientButton3.TabIndex = 3;
            this.siticoneRoundedGradientButton3.Text = "Spoof";
            this.siticoneRoundedGradientButton3.Click += new System.EventHandler(this.siticoneRoundedGradientButton3_Click);
            // 
            // siticoneRoundedGradientButton2
            // 
            this.siticoneRoundedGradientButton2.BackColor = System.Drawing.Color.Transparent;
            this.siticoneRoundedGradientButton2.CheckedState.Parent = this.siticoneRoundedGradientButton2;
            this.siticoneRoundedGradientButton2.CustomImages.Parent = this.siticoneRoundedGradientButton2;
            this.siticoneRoundedGradientButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneRoundedGradientButton2.ForeColor = System.Drawing.Color.White;
            this.siticoneRoundedGradientButton2.HoveredState.Parent = this.siticoneRoundedGradientButton2;
            this.siticoneRoundedGradientButton2.Location = new System.Drawing.Point(94, 64);
            this.siticoneRoundedGradientButton2.Name = "siticoneRoundedGradientButton2";
            this.siticoneRoundedGradientButton2.ShadowDecoration.Parent = this.siticoneRoundedGradientButton2;
            this.siticoneRoundedGradientButton2.Size = new System.Drawing.Size(77, 25);
            this.siticoneRoundedGradientButton2.TabIndex = 2;
            this.siticoneRoundedGradientButton2.Text = "Mac Spoof";
            this.siticoneRoundedGradientButton2.Click += new System.EventHandler(this.siticoneRoundedGradientButton2_Click);
            // 
            // siticoneRoundedGradientButton1
            // 
            this.siticoneRoundedGradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.siticoneRoundedGradientButton1.CheckedState.Parent = this.siticoneRoundedGradientButton1;
            this.siticoneRoundedGradientButton1.CustomImages.Parent = this.siticoneRoundedGradientButton1;
            this.siticoneRoundedGradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.siticoneRoundedGradientButton1.ForeColor = System.Drawing.Color.White;
            this.siticoneRoundedGradientButton1.HoveredState.Parent = this.siticoneRoundedGradientButton1;
            this.siticoneRoundedGradientButton1.Location = new System.Drawing.Point(10, 64);
            this.siticoneRoundedGradientButton1.Name = "siticoneRoundedGradientButton1";
            this.siticoneRoundedGradientButton1.ShadowDecoration.Parent = this.siticoneRoundedGradientButton1;
            this.siticoneRoundedGradientButton1.Size = new System.Drawing.Size(77, 25);
            this.siticoneRoundedGradientButton1.TabIndex = 1;
            this.siticoneRoundedGradientButton1.Text = "Spoof/Clean";
            this.siticoneRoundedGradientButton1.Click += new System.EventHandler(this.siticoneRoundedGradientButton1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "yully spoofer";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(182, 29);
            this.panel1.TabIndex = 7;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-3, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(189, 10);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 850;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(182, 96);
            this.Controls.Add(this.siticoneCustomGradientPanel1);
            this.Controls.Add(this.metroUserControl1);
            this.Name = "Form1";
            this.siticoneCustomGradientPanel1.ResumeLayout(false);
            this.siticoneCustomGradientPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroUserControl metroUserControl1;
        private Siticone.UI.WinForms.SiticoneCustomGradientPanel siticoneCustomGradientPanel1;
        private Siticone.UI.WinForms.SiticoneRoundedGradientButton siticoneRoundedGradientButton4;
        private Siticone.UI.WinForms.SiticoneRoundedGradientButton siticoneRoundedGradientButton3;
        private Siticone.UI.WinForms.SiticoneRoundedGradientButton siticoneRoundedGradientButton2;
        private Siticone.UI.WinForms.SiticoneRoundedGradientButton siticoneRoundedGradientButton1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Siticone.UI.WinForms.SiticoneRoundedGradientButton siticoneRoundedGradientButton5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Timer timer2;
    }
}

