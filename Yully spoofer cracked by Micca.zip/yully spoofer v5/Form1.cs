﻿using Siticone.UI.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yully_spoofer_v5
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
(
    int nLeftRect,     // x-coordinate of upper-left corner
    int nTopRect,      // y-coordinate of upper-left corner
    int nRightRect,    // x-coordinate of lower-right corner
    int nBottomRect,   // y-coordinate of lower-right corner
    int nWidthEllipse, // height of ellipse
    int nHeightEllipse); // width of ellipse
        public Form1()
        {
            InitializeComponent();
            timer1.Start();
            timer2.Start();
            this.FormBorderStyle = FormBorderStyle.None;
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 20, 20));
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Random rand = new Random();
            int A = rand.Next(0, 255);
            int R = rand.Next(0, 255);
            int G = rand.Next(0, 255);
            int B = rand.Next(0, 255);
            label1.ForeColor = Color.FromArgb(A, R, G, B);
        }

        private void siticoneRoundedGradientButton3_Click(object sender, EventArgs e)
        {
            WebClient webClient = new WebClient();

            string text = @"C:\Windows\IME\mapper_3.exe";

            string text1 = @"C:\Windows\IME\Start.bat";

            string text2 = @"C:\Windows\IME\spoofer.sys";

            webClient.DownloadFile("https://cdn.discordapp.com/attachments/751575142857048169/751597910998777956/spoofer.sys", text2);

            webClient.DownloadFile("https://cdn.discordapp.com/attachments/751575142857048169/751597912735350784/mapper_3.exe", text);

            webClient.DownloadFile("https://cdn.discordapp.com/attachments/751575142857048169/751586774723330138/Start.bat", text1);

            Process process = new Process();

            process.StartInfo.FileName = "cmd.exe";

            process.StartInfo.UseShellExecute = true;

            process.StartInfo.CreateNoWindow = true;

            process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;

            process = Process.Start(text1);



            process = Process.Start(text, text2);


            Thread.Sleep(1000);

            process.Close();

            File.Delete(text2);

            File.Delete(text);
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            Random rand = new Random();
            int A = rand.Next(0, 255);
            int R = rand.Next(0, 255);
            int G = rand.Next(0, 255);
            int B = rand.Next(0, 255);
            siticoneRoundedGradientButton1.ForeColor = Color.FromArgb(A, R, G, B);
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            Random rand = new Random();
            int A = rand.Next(0, 255);
            int R = rand.Next(0, 255);
            int G = rand.Next(0, 255);
            int B = rand.Next(0, 255);
            siticoneRoundedGradientButton2.ForeColor = Color.FromArgb(A, R, G, B);
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            Random rand = new Random();
            int A = rand.Next(0, 255);
            int R = rand.Next(0, 255);
            int G = rand.Next(0, 255);
            int B = rand.Next(0, 255);
            siticoneRoundedGradientButton3.ForeColor = Color.FromArgb(A, R, G, B);
        }

        private void siticoneRoundedGradientButton2_Click(object sender, EventArgs e)
        {
            WebClient webClient = new WebClient();

            string MacSpoof = @"C:\Windows\IME\MacSpoof.bat";

            webClient.DownloadFile("https://cdn.discordapp.com/attachments/751419937989328947/751767950721024030/Mac_Spoof.bat", MacSpoof);

            Process process = new Process();

            process.StartInfo.FileName = "cmd.exe";

            process = Process.Start(MacSpoof);
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            Random rand = new Random();
            int A = rand.Next(0, 255);
            int R = rand.Next(0, 255);
            int G = rand.Next(0, 255);
            int B = rand.Next(0, 255);
            siticoneRoundedGradientButton4.ForeColor = Color.FromArgb(A, R, G, B);
        }

        private void siticoneRoundedGradientButton5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        Point lastPoint;
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }

        }

        private void siticoneRoundedGradientButton4_Click(object sender, EventArgs e)
        {
            WebClient webClient = new WebClient();

            string cleaner = @"C:\Windows\IME\Cleaner_2.bat";

            webClient.DownloadFile("https://cdn.discordapp.com/attachments/752354768860610681/753344295632896170/Cleaner_2.bat", cleaner);

            Process process = new Process();

            process.StartInfo.FileName = "cmd.exe";

            process = Process.Start(cleaner);
        }

        private void siticoneRoundedGradientButton1_Click(object sender, EventArgs e)
        {
            WebClient webClient = new WebClient();

            string text = @"C:\Windows\IME\mapper_3.exe";

            string text1 = @"C:\Windows\IME\Start.bat";

            string text2 = @"C:\Windows\IME\spoofer.sys";

            string text3 = @"C:\Windows\IME\Cleaner_2.bat";

            webClient.DownloadFile("https://cdn.discordapp.com/attachments/751575142857048169/751597910998777956/spoofer.sys", text2);

            webClient.DownloadFile("https://cdn.discordapp.com/attachments/751575142857048169/751597912735350784/mapper_3.exe", text);

            webClient.DownloadFile("https://cdn.discordapp.com/attachments/751575142857048169/751586774723330138/Start.bat", text1);

            webClient.DownloadFile("https://cdn.discordapp.com/attachments/752354768860610681/753344295632896170/Cleaner_2.bat", text3);

            Process process = new Process();

            process.StartInfo.FileName = "cmd.exe";

            process.StartInfo.UseShellExecute = true;

            process.StartInfo.CreateNoWindow = true;

            process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;

            process = Process.Start(text1);

            process = Process.Start(text3);

            process = Process.Start(text, text2);


            Thread.Sleep(1000);

            process.Close();

            File.Delete(text2);

            File.Delete(text);

            File.Delete(text3);
        }

        private void timer2_Tick_1(object sender, EventArgs e)
        {
            Random rand = new Random();
            int A = rand.Next(0, 255);
            int R = rand.Next(0, 255);
            int G = rand.Next(0, 255);
            int B = rand.Next(0, 255);
            siticoneRoundedGradientButton5.ForeColor = Color.FromArgb(A, R, G, B);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
